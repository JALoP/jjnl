#!/bin/bash
cd "$(dirname "$0")"

mvn install:install-file \
-Dfile=beepcore.jar -DgroupId=org.beepcore-java -DartifactId=beepcore \
-Dversion=0.9.21 -Dpackaging=jar || exit 1

mvn install:install-file \
-Dfile=beeptls-jsse.jar -DgroupId=org.beepcore-java -DartifactId=beeptls-jsse \
-Dversion=0.9.21 -Dpackaging=jar || exit 1

mvn install:install-file \
-Dfile=concurrent.jar -DgroupId=EDU.oswego.cs.dl.util -DartifactId=concurrent \
-Dversion=1.3.4 -Dpackaging=jar